To add additional nodes, either:
 - drop them in this directory and add their dependencies to ../package.json
 - add their npm package name to ../package.json

